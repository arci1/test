def userfunc(x):
    return x
