public static class Batchfileiomanaged
{
    public static int Userfunc(int x)
    {
        return x + 1;
    }
}
