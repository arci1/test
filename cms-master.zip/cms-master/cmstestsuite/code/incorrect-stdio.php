<?php
$n = intval(fgets(STDIN));
echo "incorrect $n\n";
?>
