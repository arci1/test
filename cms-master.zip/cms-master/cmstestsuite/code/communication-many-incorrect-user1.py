def userfunc1(x):
    return x + 1
