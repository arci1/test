<?php
$n = intval(fgets(STDIN));
if ($n % 2 == 0)
    echo "correct 0\n";
else
    echo "correct $n\n";
?>
