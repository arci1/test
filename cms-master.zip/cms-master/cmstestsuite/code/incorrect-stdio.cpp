#include <iostream>

int main() {
    int n;
    std::cin >> n;
    std::cout << "incorrect " << n << std::endl;
    return 0;
}
