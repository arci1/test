#include <iostream>

int main() {
    int n;
    std::cin >> n;
    std::cout << "correct " << n << std::endl;
    return 0;
}
